#include"World.h"
#include"functions.h"
#include<iostream>

int main(){
	world data;
	functions calculate;
	std::string* instruction;
	//initialize game data
	data.Initialize();
	char option = 0;
	//game bucle
	while (option != 'q'){
		//get the instruction phrase
		instruction = data.get_order_data();
		//apply the order
		option = data.apply_order(instruction);
	}
	//deletes the game data before exit
	return 0;
}