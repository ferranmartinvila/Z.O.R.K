#include "entity.h"
#include "inventory.h"
#include "map.h"
#ifndef _character_
#define _character_
class character :public entity{
public:
	inventory*bag=nullptr;
	character(){
		bag = new inventory;
	}
	~character(){
		delete bag;
	}
	int pos_x, pos_y, inroom,next_room,direction[2],exit_used;
	
	//move instruction
	void apply_go_instruction(const map& game_map,const std::string* instruction){
		if (game_map.exit[exit_used].door_state&&inroom != next_room){
			pos_x = direction[0];
			pos_y = direction[1];
			inroom = next_room;
			printf("%s\n%s", game_map.room[inroom].name, game_map.room[inroom].description);
			}

		else if (game_map.exit[exit_used].door_state == false){
			printf("\nThe %s %s door is closed.", instruction[1], game_map.exit[exit_used].door_state);}
		else printf("There's anything there.");
	}

	//look instruction
	void apply_look_instruction(const map& game_map, const std::string*instruction){
		if (instruction[1] == "here")printf("%s\n%s", game_map.room[inroom].name, game_map.room[inroom].description);
		else if (instruction[1] == "me")printf("%s\n%s", name, description);
		else{
			if ((inroom == game_map.exit[exit_used].room_2) && (next_room == game_map.exit[exit_used].room_1))printf("%s", game_map.exit[exit_used].description_2);
			else if ((inroom == game_map.exit[exit_used].room_1) && (next_room == game_map.exit[exit_used].room_2))printf("%s", game_map.exit[exit_used].description_1);
			else printf("There's nothing there.");
		}
	}

	//open/close instruction
	void apply_door_instruction(map& game_map, const std::string*instruction){
		if (game_map.exit[exit_used].door == false){
			printf("There's no door.");
		}
		else if (game_map.exit[exit_used].door_state == true){
			//open
			if (instruction[0] == "open"){
				printf("The door was already open.");
			}
			//close
			if (instruction[0] == "close"){
				game_map.exit[exit_used].door_state = false;
				printf("Now the %s door from %s is closed!", instruction[1], game_map.room[inroom].name);
			}
		}
		else{
			//open
			if (instruction[0] == "open"){
				game_map.exit[exit_used].door_state = true;
				printf("Now the %s door from %s is open!", instruction[1], game_map.room[inroom].name);
			}
			//close
			if (instruction[0] == "close"){
				printf("The door was already closed.");
			}
		}
	}


};
#endif