#define _CRT_SECURE_NO_WARNINGS
#include"World.h"
#include<string.h>

void world::Initialize(){
	//OBJECTS

	//Oil Light
	object[0].name = "Oil Light";
	object[0].description = "An old but usefull oil light.";
	object[0].location = 1;
	//Golden Dagger
	object[1].name = "Golden Dagger";
	object[1].description = "A little gold Dagger that get the attention of any person that knows about metals.";
	object[1].location = 4;
	//Furnace Key
	object[2].name = "Furnace Key";
	object[2].description = "A big and strange key which seems to have been used.";
	object[2].location = 8;
	//Marcus Notes
	object[3].name = "Marcus Notes";
	object[3].description = "Old and poorly maintained notes. Stained by humidity and illegible in certain parts.";
	object[3].location = 2;
	//Raw food
	object[4].name = "Raw food";
	object[4].description = "Food with a quite advanced state of rot. You will be healthier if you don't eat it.";
	object[4].location = 1;
	//Wine
	object[5].name = "Wine";
	object[5].description = "An alcoholic drink made from fermented grape juice. This drink is able to persuade anyone.";
	object[5].location = 5;
	//Knight's Sword
	object[6].name = "Knight's Sword";
	object[6].description = "A huge iron sword full of drawings and with a dragon on the handle.";
	object[6].location = 8;
	//Bloody Sword
	object[7].name = "Bloody Sword";
	object[7].description = "A magic red sword. It emits a strange energy that provides a supernatural force at the knight that uses it.";
	object[7].location = 9;


	//CHARACTER
	me->pos_x = me->pos_y = me->inroom = me->exit_used = me->next_room = me->direction[0] = me->direction[1] = 0;
	me->name = "Earl the knight";
	me->description = "You are a brave knight from a far village called Gandar there all the people respects you but here in Bloody Sword nobody knows you.";
	//inventory
	for (int k = 0; k < 4; k++){
		me->bag->cell[k].name = nullptr;
		me->bag->cell[k].description = nullptr;
		me->bag->cell[k].name = nullptr;
	}

	//MAP
	//Principal Square Data
	game_map->room[0].name = "Principal Square";
	game_map->room[0].description = "Central Square of Bloody Sword. This square is impollute and there's one of the best kingdom knights sorrounding it. Maybe someone important for the king lives arround here.";
	//Coordenades
	game_map->room[0].x_cor = game_map->room[0].y_cor = 0;
	//Dead end street Data
	game_map->room[1].name = "Dead end Street";
	game_map->room[1].description = "Abandoned street full of rubbish that ends in the wall of the city. Is difficult to stay here to much time, so people only comes here to throw his shit.";
	//Coordenades
	game_map->room[1].x_cor = 1;
	game_map->room[1].y_cor = 0;
	//Ruined House Data
	game_map->room[2].name = "Ruined House";
	game_map->room[2].description = "This house will fall down at any moment it practically don't have roof and you can smell the odor of the street next to this house. Surprisingly here there's a poor family living or more precisely surviving.";
	//Coordenades
	game_map->room[2].x_cor = 0;
	game_map->room[2].y_cor = -1;
	//Jack's House Lobby Data
	game_map->room[3].name = "Jack's House Lobby";
	game_map->room[3].description = "Little and luxury room for recieve guests. Full of family portraits.";
	//Coordenades
	game_map->room[3].x_cor = 0;
	game_map->room[3].y_cor = 1;
	//Jack's House Main Room Data
	game_map->room[4].name = "Jack's House Main Room";
	game_map->room[4].description = "Biggest room of the house filled with belic objects with an incalculable valor. Like bright golden swords.";
	//Coordenades
	game_map->room[4].x_cor = 0;
	game_map->room[4].y_cor = 2;
	//Jack's House Kitchen Data
	game_map->room[5].name = "Jack's House Kitchen";
	game_map->room[5].description = "Big kichen fully of slaves working hard for the owners. Isn't so clean for be a kitchen probably the owners don't enter. They must be very busy.";
	//Room coordenades
	game_map->room[5].x_cor = 1;
	game_map->room[5].y_cor = 2;
	//Jack's House Bathroom Data
	game_map->room[6].name = "Jack's House Bathroom";
	game_map->room[6].description = "The most clean room of the house probably because there's only a hole , a mirror and a pair of vases.";
	//Room coordenades
	game_map->room[6].x_cor = 0;
	game_map->room[6].y_cor = 3;
	//Jack's Forge Shop Data
	game_map->room[7].name = "Jack's Forge Shop";
	game_map->room[7].description = "Little room full of iron tools and with a showcase of weapons behind the counter.";
	//Room coordenades
	game_map->room[7].x_cor = -1;
	game_map->room[7].y_cor = 0;
	//Jack's Forge Warehouse Data
	game_map->room[8].name = "Jack's Forge Warehouse";
	game_map->room[8].description = "Amazingly big and dirty room full of metal pieces.Probably this is the biggest underground warehouse that I have ever seen.";
	//Room coordenades
	game_map->room[8].x_cor = -2;
	game_map->room[8].y_cor = 0;
	//Jack's Forge Large Furnace Data
	game_map->room[9].name = "Jack's Forge Large Furnace";
	game_map->room[9].description = "Excessively large furnace that can melt the most resistant metals.It not seems to have been used for melt metals.";
	// room coordenades
	game_map->room[9].x_cor = -2;
	game_map->room[9].y_cor = -1;





	//Principal Square & Dead end Street
	game_map->exit[0].room_1 = 0;
	game_map->exit[0].room_2 = 1;
	game_map->exit[0].description_1 = "There's an abandoned street. It don't seems to lead anywhere but the polluted air makes impossible see the end.";
	game_map->exit[0].description_2 = "There's the principal Square where you come from better if you go there and get out of this mount of rubbish.";
	game_map->exit[0].door = false;
	game_map->exit[0].door_state = true;
	//Principal Square & Ruined House
	game_map->exit[1].room_1 = 0;
	game_map->exit[1].room_2 = 2;
	game_map->exit[1].description_1 = "Under the herbs there's a ruined house with only one room. I don't know how there's people living there.";
	game_map->exit[1].description_2 = "There's the principal Square where you come from probably is more safe than this ruined house. Better if you go there.";
	game_map->exit[1].door = true;
	game_map->exit[1].door_state = true;
	//Principal Square & Jack's House Lobby
	game_map->exit[2].room_1 = 0;
	game_map->exit[2].room_2 = 3;
	game_map->exit[2].description_1 = "A palace!? This is a poor district! This is probably the most big and shiniy build of Bloody Sword.";
	game_map->exit[2].description_2 = "There's a big wood door that takes you outside.";
	game_map->exit[2].door = true;
	game_map->exit[2].door_state = false;
	//Principal Square & Jack's Forge Shop
	game_map->exit[3].room_1 = 0;
	game_map->exit[3].room_2 = 7;
	game_map->exit[3].description_1 = "There's little but well maintained forge. In the door there's a poster where you can read 'Jack's Forge'.";
	game_map->exit[3].description_2 = "There's the door to go outside at the Principal Square.";
	game_map->exit[3].door = true;
	game_map->exit[3].door_state = true;
	//Shop & Warehouse
	game_map->exit[4].room_1 = 7;
	game_map->exit[4].room_2 = 8;
	game_map->exit[4].description_1 = "Between the tools there's a small door that probalby takes you to the warehouse.";
	game_map->exit[4].description_2 = "That's the little door for go back to the Jack's Shop.";
	game_map->exit[4].door = true;
	game_map->exit[4].door_state = true;
	//Warehouse & Large Furnace
	game_map->exit[5].room_1 = 8;
	game_map->exit[5].room_2 = 9;
	game_map->exit[5].description_1 = "There's a big door practically invisible for the dirt.";
	game_map->exit[5].description_2 = "There's the warehouse where you come from.";
	game_map->exit[5].door = true;
	game_map->exit[5].door_state = true;
	// Lobby & Main Room
	game_map->exit[6].room_1 = 3;
	game_map->exit[6].room_2 = 4;
	game_map->exit[6].description_1 = "It seems to be some shiniy objects right there or maybe is the sun reflected in that metal piece.";
	game_map->exit[6].description_2 = "There's the lobby.";
	game_map->exit[6].door = false;
	game_map->exit[6].door_state = true;
	// Main Room & Kitchen
	game_map->exit[7].room_1 = 4;
	game_map->exit[7].room_2 = 5;
	game_map->exit[7].description_1 = "Is impossible to don't realize about the noise that comes from that room. It sounds like a group of people where fighting.";
	game_map->exit[7].description_2 = "It seems to be some shiniy objects right there or maybe is the sun reflected in that metal piece.";
	game_map->exit[7].door = true;
	game_map->exit[7].door_state = true;
	//Main Room & Bathroom
	game_map->exit[8].room_1 = 4;
	game_map->exit[8].room_2 = 6;
	game_map->exit[8].description_1 = "Theres a door full of crystal decorations. Throwght it is possible to see a mirror but no more.";
	game_map->exit[8].description_2 = "It seems to be some shiniy objects right there or maybe is the sun reflected in that metal piece.";
	game_map->exit[8].door = true;
	game_map->exit[8].door_state = true;
}

std::string* world::get_order_data(){

	//array that contain all de phrase characters
	char phrase[40];
	//array with the different words
	char*word[4] = { nullptr, nullptr, nullptr, nullptr };
	//number of words entered by the user
	std::string*str = new std::string[4];

	//Action fractioner & focus
	printf("Enter the next action:");
	//gets all the words together
	gets_s(phrase);
	//break the phrase in different strings
	word[0] = strtok(phrase, " ");
	for (int k = 1; k < 4; k++){
		if (word[k - 1] != NULL){
			word[k] = strtok(NULL, " ");
			str[k - 1] = word[k - 1];
		}
	}

	//generates a variable with the number of the room that the player is focused and coords of this room
	if (str[0] == "go" || str[0] == "look" || str[0] == "open" || str[0] == "close"){
		if (str[1] == "north")me->direction[1]++;
		else if (str[1] == "east")me->direction[0]++;
		else if (str[1] == "south")me->direction[1]--;
		else if (str[1] == "west")me->direction[0]--;
	}

	//calculates the room where you focus the action and the exit between your room and it
	for (int k = 0; k < 10; k++){
		if (game_map->room[k].x_cor == me->direction[0] && game_map->room[k].y_cor == me->direction[1]){
			me->next_room = k;
			k = 9;
		}
		else me->next_room = me->inroom;
	}
	for (int i = 0; i < 9; i++){
		if ((game_map->exit[i].room_1 == me->inroom || game_map->exit[i].room_2 == me->inroom) && (game_map->exit[i].room_1 == me->next_room || game_map->exit[i].room_2 == me->next_room)){
			me->exit_used = i;
			i = 9;
		}
	}
	return str;
}

char world::apply_order(const std::string*instruction){
	if (instruction[0] == "quit")return 'q';
	if (instruction[0] == "help"){ printf("\nLook here -> Look this room\nLook + direction -> Look exits\nGo + direction ->Move\nOpen + direction + door -> Open door\nClose + direction + door-> Close door"); }
	else if (instruction[0] == "go")me->apply_go_instruction(*game_map,instruction); 
	else if (instruction[0] == "look")me->apply_look_instruction(*game_map, instruction);
	else if ((instruction[0] == "open" || instruction[0] == "close")&&instruction[2]=="door")me->apply_door_instruction(*game_map, instruction);
	/*else if (instruction[0] == "pick"){}
	else if (instruction[0] == "drop"){}
	 */



}
