#include"World.h"

#ifndef _funcions_
#define _funcions_
class functions{
public:
	char enter_and_apply_order(world&);
};
#endif