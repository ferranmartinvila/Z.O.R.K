#include"entity.h"
#ifndef _rooms_
#define _rooms_
class rooms :public entity{
public:
	int x_cor, y_cor;
};
#endif