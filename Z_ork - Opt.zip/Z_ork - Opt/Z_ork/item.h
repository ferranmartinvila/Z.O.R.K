#include "entity.h"
#ifndef _item_
#define _item_
class item :public entity{
public:
	int location;
};
#endif