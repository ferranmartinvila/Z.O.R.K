#ifndef _entity_
#define _entity_
class entity{
public:
	char*name, *description;
};
#endif