#ifndef _exits_
#define _exits_
class exits{
public:
	int room_1, room_2;
	char* description_1, *description_2;
	bool door, door_state;
};
#endif