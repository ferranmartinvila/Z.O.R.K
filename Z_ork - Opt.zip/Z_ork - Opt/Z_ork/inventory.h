#include"item.h"
#ifndef _inventory_
#define _inventory_
class inventory{
public:
	item*cell=nullptr;
	inventory(){
		cell = new item[4];
	}
	~inventory(){
		delete[]cell;
	}
};
#endif
